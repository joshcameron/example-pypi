def main():
    print("Hello from pypi-package!")


if __name__ == "__main__":
    main()
